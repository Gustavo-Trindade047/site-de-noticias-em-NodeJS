var mongoose = require('mongoose');
var Schema = mongoose.Schema; // O objeto Schema é utilizado para estruturar o documento e definir os campos do modelo.

// Define a estrutura do modelo de documento para a coleção 'posts'
var postSchema = new Schema({
    titulo: String, // Campo 'titulo' do tipo String
    imagem: String, // Campo 'imagem' do tipo String
    categoria: String, // Campo 'categoria' do tipo String
    conteudo: String, // Campo 'conteudo' do tipo String
    slug: String, // Campo 'slug' do tipo String
    autor: String, // Campo 'autor' do tipo String
    views: Number, // Campo 'views' do tipo Number
    descricao: String // Campo 'descricao' do tipo String
}, { collection: 'posts' }); // Define o nome da coleção como 'posts'

// Cria o modelo 'Posts' com base no esquema 'postSchema'
var Posts = mongoose.model("Posts", postSchema);

// Exporta o modelo 'Posts' para ser utilizado em outros arquivos
module.exports = Posts;
