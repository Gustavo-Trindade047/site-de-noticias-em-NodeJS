const express = require('express');
const mongoose = require('mongoose');
var bodyParser = require('body-parser')

const path = require('path');

const app = express();

const Posts = require('./Posts.js');

// Conecta-se ao banco de dados MongoDB usando o Mongoose
mongoose.connect('mongodb+srv://jornalzin_do_otaku:123senha@cluster0.ebmg08a.mongodb.net/?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(function() {
  console.log('Conectado com sucesso');
}).catch(function(err) {
  console.log(err.message);
})

// Configura o middleware para analisar corpos de solicitação codificados em JSON
app.use(bodyParser.json());

// Configura o middleware para analisar corpos de solicitação codificados em URL
app.use(bodyParser.urlencoded({
  extended: true
}));

app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// Define o diretório 'public' como o diretório estático para servir arquivos estáticos
app.use('/public', express.static(path.join(__dirname, 'public')));

// Define o diretório 'pages' como o diretório para as visualizações (views)
app.set('views', path.join(__dirname, '/pages'));


// Rota para a página inicial
app.get('/', (req, res) => {
  
  if (req.query.busca == null) {
    // Busca todos os posts e classifica por '_id' em ordem decrescente
    Posts.find({}).sort({'_id': -1}).exec(function(err, posts) {
      posts = posts.map(function(val) {
        return {
          titulo: val.titulo,
          conteudo: val.conteudo,
          imagem: val.imagem,
          slug: val.slug,
          categoria: val.categoria,
          descricao: val.descricao
        }
      })

      // Busca os 3 posts com mais visualizações
      Posts.find({}).sort({'views': -1}).limit(3).exec(function(err, postsTop) {
        postsTop = postsTop.map(function(val) {
          return {
            titulo: val.titulo,
            conteudo: val.conteudo,
            imagem: val.imagem,
            slug: val.slug,
            categoria: val.categoria,
            views: val.views,
            descricao: val.descricao
          }
        })

        // Renderiza a página 'home' com os posts e os posts mais visualizados
        res.render('home', { posts: posts, postsTop: postsTop });
      })
    })
  } else {
    // Faz uma busca por título (case-insensitive)
    Posts.find({ titulo: { $regex: req.query.busca, $options: "i" } }, function(err, posts) {
      posts = posts.map(function(val) {
        return {
          titulo: val.titulo,
          conteudo: val.conteudo,
          descricao: val.descricao,
          imagem: val.imagem,
          slug: val.slug,
          categoria: val.categoria,
          views: val.views
        }
      })

      // Renderiza a página 'busca' com os posts encontrados e a contagem de resultados
      res.render('busca', { posts: posts, contagem: posts.length });
    })
  }
});

// Rota para exibir um post específico com base no slug
app.get('/:slug', (req, res) => {
  Posts.findOneAndUpdate({ slug: req.params.slug }, { $inc: { views: 1 } }, { new: true }, function(err, resposta) {
    if (resposta != null) {
      // Busca os 3 posts com mais visualizações
      Posts.find({}).sort({'views': -1}).limit(3).exec(function(err, postsTop) {
        postsTop = postsTop.map(function(val) {
          return {
            titulo: val.titulo,
            conteudo: val.conteudo,
            imagem: val.imagem,
            slug: val.slug,
            categoria: val.categoria,
            views: val.views,
            descricao: val.descricao
          }
        })

        // Renderiza a página 'single' com o post selecionado e os posts mais visualizados
        res.render('single', { noticia: resposta, postsTop: postsTop });
      })
    } else {
      // Redireciona para a página inicial se o post não for encontrado
      res.redirect('/');
    }
  })
});
app.get('/quemsomos',(req, res) => {
  res.render('pages/quemsomos');
});

// Inicia o servidor na porta 2000
app.listen(2000, () => {
  console.log('Servidor rodando!');
})
